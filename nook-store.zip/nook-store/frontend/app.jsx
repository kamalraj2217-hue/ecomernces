const { useState, useEffect, useRef } = React;
const money = n => "₹" + n.toLocaleString("en-IN");

// Small helper for talking to the Python API
const api = (url, body) =>
  fetch("/api" + url, body && { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
    .then(r => r.json().then(d => (r.ok ? d : Promise.reject(d))));

// useState that is saved in the browser
function useStore(key, initial) {
  const [v, set] = useState(() => { try { return JSON.parse(localStorage.getItem(key)) ?? initial; } catch { return initial; } });
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(v)); } catch {} }, [v]);
  return [v, set];
}

function Search({ q, setQ, onPick }) {
  const [open, setOpen] = useState(false), [sg, setSg] = useState([]), ref = useRef();
  useEffect(() => {
    if (!q.trim()) { setSg([]); return; }
    const t = setTimeout(() => api("/products?" + new URLSearchParams({ q, limit: 5 })).then(d => setSg(d.products)), 150);
    return () => clearTimeout(t);
  }, [q]);
  useEffect(() => {
    const key = e => {
      if (e.key === "/" && !/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); ref.current.focus(); }
      if (e.key === "Escape") setOpen(false);
    };
    const click = e => { if (!e.target.closest(".search")) setOpen(false); };
    document.addEventListener("keydown", key); document.addEventListener("click", click);
    return () => { document.removeEventListener("keydown", key); document.removeEventListener("click", click); };
  }, []);
  return (
    <div className="search">
      <input ref={ref} value={q} autoComplete="off" aria-label="Search products" placeholder="Search products  (press / to focus)"
        onChange={e => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)}
        onKeyDown={e => { if (e.key === "Enter") { setOpen(false); document.getElementById("shop").scrollIntoView(); } }} />
      {q && <button id="clr" aria-label="Clear search" onClick={() => { setQ(""); ref.current.focus(); }}>✕</button>}
      {open && q.trim() && (
        <div id="sg">
          {sg.length ? sg.map(p => (
            <button key={p.id} onClick={() => { setOpen(false); onPick(p); }}>
              <span>{p.emoji}</span><span>{p.name}</span><b>{money(p.price)}</b>
            </button>
          )) : <p>No results for "{q}". Try "mug" or "lamp".</p>}
        </div>
      )}
    </div>
  );
}

function Card({ p, wished, onWish, onAdd, onView }) {
  return (
    <article className="card">
      <button className="thumb" style={{ background: p.bg }} onClick={() => onView(p)} aria-label={"View " + p.name}>
        {p.emoji}{p.tag && <span className="tag">{p.tag}</span>}
      </button>
      <button className="heart" onClick={() => onWish(p.id)} aria-label={wished ? "Remove from wishlist" : "Add to wishlist"}>{wished ? "♥" : "♡"}</button>
      <div className="info">
        <h3>{p.name}</h3>
        <div className="rate">★ {p.rating} · {p.category}</div>
        <div className="price">{money(p.price)}{p.old_price && <s>{money(p.old_price)}</s>}</div>
        <button className="btn dark" onClick={() => onAdd(p.id)}>Add to cart</button>
      </div>
    </article>
  );
}

const F = ({ id, label, ...rest }) => <div><label htmlFor={id}>{label}</label><input id={id} name={id} required {...rest} /></div>;

function Checkout({ lines, total, coupon, onDone, onClose }) {
  const [error, setError] = useState(""), [busy, setBusy] = useState(false);
  const submit = async e => {
    e.preventDefault(); setBusy(true); setError("");
    try {
      const r = await api("/orders", { customer: Object.fromEntries(new FormData(e.target)), items: lines.map(l => ({ id: l.p.id, qty: l.qty })), coupon: coupon && coupon.code });
      onDone(r.order_id);
    } catch (x) { setError(x.error || "Could not reach the server. Try again."); setBusy(false); }
  };
  return (
    <>
      <button className="x" onClick={onClose} aria-label="Close">✕</button>
      <h2>Checkout</h2>
      <form onSubmit={submit}>
        <F id="name" label="Full name" autoComplete="name" />
        <div className="two"><F id="email" label="Email" type="email" autoComplete="email" /><F id="phone" label="Phone" type="tel" pattern="[0-9]{10}" title="10-digit mobile number" /></div>
        <F id="address" label="Address" autoComplete="street-address" />
        <div className="two"><F id="city" label="City" /><F id="pin" label="PIN code" pattern="[0-9]{6}" title="6-digit PIN code" /></div>
        <label htmlFor="payment">Payment</label>
        <select id="payment" name="payment"><option>Cash on delivery</option><option>UPI</option><option>Card</option></select>
        {error && <p role="alert" style={{ color: "#c0392b", marginTop: 10 }}>{error}</p>}
        <div className="row total" style={{ margin: "16px 0 10px" }}><span>Total</span><span>{money(total)}</span></div>
        <button className="btn block" disabled={busy}>{busy ? "Placing order…" : "Place order"}</button>
      </form>
    </>
  );
}

function App() {
  const [all, setAll] = useState([]), [shown, setShown] = useState([]), [cats, setCats] = useState([]);
  const [q, setQ] = useState(""), [cat, setCat] = useState("All"), [price, setPrice] = useState("a"), [sort, setSort] = useState("feat");
  const [wishOnly, setWishOnly] = useState(false), [loading, setLoading] = useState(true), [offline, setOffline] = useState(false);
  const [cart, setCart] = useStore("cart", {}), [wish, setWish] = useStore("wish", []);
  const [theme, setTheme] = useStore("theme", "light"), [coupon, setCoupon] = useStore("coupon", null);
  const [drawer, setDrawer] = useState(false), [modal, setModal] = useState(null), [toast, setToast] = useState(""), [code, setCode] = useState("");

  const flash = m => { setToast(m); setTimeout(() => setToast(""), 1800); };

  useEffect(() => {
    api("/products").then(d => setAll(d.products)).catch(() => setOffline(true));
    api("/categories").then(d => setCats(d.categories)).catch(() => {});
  }, []);
  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => api("/products?" + new URLSearchParams({ q, category: cat, price, sort }))
      .then(d => { setShown(d.products); setLoading(false); })
      .catch(() => { setOffline(true); setLoading(false); }), 200);
    return () => clearTimeout(t);
  }, [q, cat, price, sort]);
  useEffect(() => {
    const esc = e => { if (e.key === "Escape") { setDrawer(false); setModal(null); } };
    document.addEventListener("keydown", esc); return () => document.removeEventListener("keydown", esc);
  }, []);

  const lines = Object.entries(cart).map(([id, qty]) => ({ p: all.find(x => x.id == id), qty })).filter(l => l.p);
  const sub = lines.reduce((s, l) => s + l.p.price * l.qty, 0);
  const disc = coupon ? Math.round(sub * coupon.pct / 100) : 0;
  const ship = sub && sub < 1999 ? 99 : 0, total = sub - disc + ship;
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const list = wishOnly ? shown.filter(p => wish.includes(p.id)) : shown;

  const add = (id, n = 1) => setCart(c => { const x = { ...c }, v = (c[id] || 0) + n; v > 0 ? x[id] = v : delete x[id]; return x; });
  const addFlash = id => { add(id); flash("Added to cart"); };
  const toggleWish = id => setWish(w => w.includes(id) ? w.filter(x => x != id) : [...w, id]);
  const applyCoupon = () => api("/coupon", { code }).then(d => { setCoupon(d); flash(`Coupon applied: ${d.pct}% off`); })
    .catch(e => { setCoupon(null); flash(code ? e.error : "Coupon removed"); });
  const closeAll = () => { setDrawer(false); setModal(null); };

  return (
    <>
      <header><div className="wrap bar">
        <a className="logo" href="#" style={{ color: "#fff", textDecoration: "none" }}>nook<span>.</span></a>
        <Search q={q} setQ={setQ} onPick={p => setModal({ type: "view", p })} />
        <button className="icon-btn" aria-label="Toggle dark mode" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? "☀️" : "🌙"}</button>
        <button className="icon-btn" aria-label="Show wishlist" onClick={() => { setWishOnly(!wishOnly); setCat("All"); flash(wishOnly ? "Showing all products" : "Showing wishlist"); document.getElementById("shop").scrollIntoView(); }}>♡<span className="badge">{wish.length}</span></button>
        <button className="icon-btn" aria-label="Open cart" onClick={() => setDrawer(true)}>🛒<span className="badge">{count}</span></button>
      </div></header>

      <section className="hero"><div className="wrap">
        <div>
          <h1>Everyday things, made to be loved.</h1>
          <p>Gear, home and desk essentials picked for quality and fair prices. Free delivery on orders above ₹1,999.</p>
          <a className="btn" href="#shop">Shop now</a>
        </div>
        <div className="hero-art" aria-hidden="true">🎧☕🪴🎒</div>
      </div></section>

      <main className="wrap" id="shop">
        <div className="perks"><span>🚚 <b>Free delivery</b> over ₹1,999</span><span>↩️ <b>7-day</b> easy returns</span><span>🔒 <b>Secure</b> checkout</span><span>💬 <b>Support</b> 9am–9pm</span></div>
        <div className="tools">
          <div className="chips" role="group" aria-label="Categories">
            {["All", ...cats].map(c => <button key={c} className="chip" aria-pressed={c === cat} onClick={() => { setCat(c); setWishOnly(false); }}>{c}</button>)}
          </div>
          <select id="price" aria-label="Filter by price" value={price} onChange={e => setPrice(e.target.value)}>
            <option value="a">Any price</option><option value="l">Under ₹500</option><option value="m">₹500 – ₹2,000</option><option value="h">Over ₹2,000</option>
          </select>
          <select aria-label="Sort products" value={sort} onChange={e => setSort(e.target.value)}>
            <option value="feat">Featured</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option><option value="rate">Top rated</option>
          </select>
        </div>
        <div className="grid" aria-live="polite">
          {offline ? <p className="empty">Cannot reach the store server. Start it with <code>python app.py</code> and refresh.</p>
            : loading && !shown.length ? <p className="empty">Loading products…</p>
            : list.length ? list.map(p => <Card key={p.id} p={p} wished={wish.includes(p.id)} onWish={toggleWish} onAdd={addFlash} onView={p => setModal({ type: "view", p })} />)
            : <p className="empty">{wishOnly ? "Your wishlist is empty. Tap ♡ on a product to save it." : "No products match your search. Try another word or category."}</p>}
        </div>
      </main>

      <footer><div className="wrap">
        <div><b style={{ color: "#fff" }}>nook.</b><br />Made for everyday living.<br />support@nook.example</div>
        <div>Shipping · Returns · Track order · Contact</div>
        <form onSubmit={e => { e.preventDefault(); flash("Subscribed. Thank you!"); e.target.reset(); }}>
          <input type="email" required placeholder="Your email" aria-label="Email for newsletter" /><button className="btn">Subscribe</button>
        </form>
      </div></footer>

      <div className={"overlay" + (drawer || modal ? " open" : "")} onClick={closeAll}></div>

      <aside className={"drawer" + (drawer ? " open" : "")} aria-label="Shopping cart">
        <header><h2>Your cart</h2><button className="icon-btn" aria-label="Close cart" onClick={() => setDrawer(false)}>✕</button></header>
        <div className="lines">
          {lines.length ? lines.map(({ p, qty }) => (
            <div className="line" key={p.id}>
              <div className="em" style={{ background: p.bg }}>{p.emoji}</div>
              <div><b>{p.name}</b><br />
                <div className="qty"><button aria-label="Decrease quantity" onClick={() => add(p.id, -1)}>−</button><span>{qty}</span><button aria-label="Increase quantity" onClick={() => add(p.id, 1)}>+</button></div>
              </div>
              <div style={{ textAlign: "right" }}><b>{money(p.price * qty)}</b><br /><button className="rm" onClick={() => add(p.id, -qty)}>Remove</button></div>
            </div>
          )) : <p className="empty">Your cart is empty.<br />Add something you like.</p>}
        </div>
        {lines.length > 0 && (
          <div className="foot">
            <p className="note" style={sub < 1999 ? { color: "var(--muted)" } : null}>{sub < 1999 ? `Add ${money(1999 - sub)} more for free delivery.` : "You got free delivery."}</p>
            <div className="cpn"><input value={code} onChange={e => setCode(e.target.value)} placeholder="Coupon code (try NOOK10)" aria-label="Coupon code" /><button className="chip" onClick={applyCoupon}>Apply</button></div>
            <div className="row"><span>Subtotal</span><span>{money(sub)}</span></div>
            {disc > 0 && <div className="row" style={{ color: "var(--ok)" }}><span>Coupon {coupon.code}</span><span>−{money(disc)}</span></div>}
            <div className="row"><span>Delivery</span><span>{ship ? money(ship) : "Free"}</span></div>
            <div className="row total"><span>Total</span><span>{money(total)}</span></div>
            <button className="btn block" style={{ marginTop: 12 }} onClick={() => { setDrawer(false); setModal({ type: "checkout" }); }}>Checkout</button>
          </div>
        )}
      </aside>

      {modal && (
        <div className="modal open" role="dialog" aria-modal="true">
          {modal.type === "view" && (
            <>
              <button className="x" onClick={() => setModal(null)} aria-label="Close">✕</button>
              <div className="pd">
                <div className="big" style={{ background: modal.p.bg }}>{modal.p.emoji}</div>
                <div>
                  <h2>{modal.p.name}</h2><div className="rate">★ {modal.p.rating} · {modal.p.category}</div>
                  <p style={{ margin: "10px 0" }}>{modal.p.description}</p>
                  <div className="price" style={{ marginBottom: 14 }}>{money(modal.p.price)}{modal.p.old_price && <s>{money(modal.p.old_price)}</s>}</div>
                  <button className="btn block" onClick={() => { addFlash(modal.p.id); setModal(null); }}>Add to cart</button>
                </div>
              </div>
            </>
          )}
          {modal.type === "checkout" && <Checkout lines={lines} total={total} coupon={coupon} onClose={() => setModal(null)}
            onDone={id => { setCart({}); setCoupon(null); setCode(""); setModal({ type: "done", id }); }} />}
          {modal.type === "done" && (
            <div className="done"><div className="tick">✅</div><h2>Order placed</h2>
              <p>Your order <b>{modal.id}</b> is confirmed and saved.</p><br />
              <button className="btn" onClick={() => setModal(null)}>Continue shopping</button></div>
          )}
        </div>
      )}
      <div id="toast" className={toast ? "show" : ""} role="status">{toast}</div>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
