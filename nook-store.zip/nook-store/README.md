# Nook store (React + Python/Flask)

## Run
    cd backend
    pip install -r requirements.txt
    python app.py
Open http://127.0.0.1:5000

## Structure
- frontend/index.html, styles.css, app.jsx  - React UI (React loads from a CDN, no npm needed)
- backend/app.py - Flask API (products, search, coupons, orders) and serves the frontend
- backend/products.json - product catalogue (edit to add products)
- backend/store.db - SQLite orders (created on first run)

## API
GET /api/products?q=&category=&price=&sort=&limit=    GET /api/categories
POST /api/coupon {code}    POST /api/orders {customer, items, coupon}
GET /api/orders (header X-Admin-Key; set the ADMIN_KEY environment variable)

Coupons: NOOK10 (10%), WELCOME5 (5%). Payments are not real: connect Razorpay in create_order().
