"""Nook store backend: Flask + SQLite. Also serves the React frontend."""
import json, os, re, sqlite3, uuid
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory

BASE = Path(__file__).parent
app = Flask(__name__, static_folder=str(BASE.parent / "frontend"), static_url_path="")

PRODUCTS = json.loads((BASE / "products.json").read_text(encoding="utf-8"))
BY_ID = {p["id"]: p for p in PRODUCTS}
COUPONS = {"NOOK10": 10, "WELCOME5": 5}          # code -> percent off
FREE_SHIPPING_ABOVE, SHIPPING_FEE = 1999, 99
ADMIN_KEY = os.environ.get("ADMIN_KEY", "change-me")
DB = BASE / "store.db"


def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con


with db() as con:
    con.execute("""CREATE TABLE IF NOT EXISTS orders(
        id TEXT PRIMARY KEY, created TEXT DEFAULT CURRENT_TIMESTAMP,
        customer TEXT, items TEXT, coupon TEXT, total INTEGER, payment TEXT)""")


def err(msg, code=400):
    return jsonify(error=msg), code


def in_price(v, r):
    return r == "a" or (r == "l" and v < 500) or (r == "m" and 500 <= v <= 2000) or (r == "h" and v > 2000)


def totals(items, code=None):
    sub = sum(i["price"] * i["qty"] for i in items)
    pct = COUPONS.get((code or "").upper(), 0)
    disc = round(sub * pct / 100)
    ship = SHIPPING_FEE if 0 < sub < FREE_SHIPPING_ABOVE else 0
    return {"subtotal": sub, "discount": disc, "shipping": ship, "total": sub - disc + ship}


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/categories")
def categories():
    return jsonify(categories=sorted({p["category"] for p in PRODUCTS}))


@app.get("/api/products")
def products():
    words = request.args.get("q", "").lower().split()
    cat = request.args.get("category", "All")
    price = request.args.get("price", "a")
    sort = request.args.get("sort", "feat")
    limit = request.args.get("limit", type=int)
    items = [p for p in PRODUCTS
             if (cat == "All" or p["category"] == cat)
             and in_price(p["price"], price)
             and all(w in f'{p["name"]} {p["category"]} {p["description"]}'.lower() for w in words)]
    if sort == "low":
        items.sort(key=lambda p: p["price"])
    elif sort == "high":
        items.sort(key=lambda p: -p["price"])
    elif sort == "rate":
        items.sort(key=lambda p: -p["rating"])
    return jsonify(products=items[:limit] if limit else items)


@app.post("/api/coupon")
def coupon():
    code = ((request.get_json(silent=True) or {}).get("code") or "").strip().upper()
    if code not in COUPONS:
        return err("Invalid coupon code.")
    return jsonify(code=code, pct=COUPONS[code])


@app.post("/api/orders")
def create_order():
    d = request.get_json(silent=True) or {}
    c = {k: str(v).strip() for k, v in (d.get("customer") or {}).items()}
    if any(not c.get(k) for k in ("name", "email", "phone", "address", "city", "pin")):
        return err("Please fill in all the fields.")
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", c["email"]):
        return err("Enter a valid email address.")
    if not re.fullmatch(r"\d{10}", c["phone"]):
        return err("Phone number must be 10 digits.")
    if not re.fullmatch(r"\d{6}", c["pin"]):
        return err("PIN code must be 6 digits.")
    items = []
    for it in d.get("items") or []:
        p, qty = BY_ID.get(it.get("id")), it.get("qty")
        if not p or not isinstance(qty, int) or not 1 <= qty <= 20:
            return err("Your cart has an invalid item.")
        items.append({"id": p["id"], "name": p["name"], "qty": qty, "price": p["price"]})
    if not items:
        return err("Your cart is empty.")
    t = totals(items, d.get("coupon"))        # price is always recalculated on the server
    oid = "NK" + uuid.uuid4().hex[:6].upper()
    with db() as con:
        con.execute("INSERT INTO orders(id,customer,items,coupon,total,payment) VALUES(?,?,?,?,?,?)",
                    (oid, json.dumps(c), json.dumps(items), d.get("coupon"), t["total"], c.get("payment", "")))
    return jsonify(order_id=oid, **t), 201


@app.get("/api/orders")
def list_orders():
    if request.headers.get("X-Admin-Key") != ADMIN_KEY:
        return err("Not allowed.", 401)
    with db() as con:
        rows = [dict(r) for r in con.execute("SELECT * FROM orders ORDER BY created DESC")]
    return jsonify(orders=rows)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
